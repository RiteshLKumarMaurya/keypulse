# KeyPulse

KeyPulse is a privacy-first static browser utility for extracting environment/config variable names and comparing two KEY=value files.

## Privacy architecture
All file reading, parsing and comparison happens in the browser. No file upload endpoint, backend, database, analytics service or external API is required.

Local history is optional browser storage. It contains only metadata (filenames, counts, mode, status totals and timestamps), never configuration values.

## Run
Open `index.html` directly, or deploy the folder to any static host.

## Payment
The footer includes a UPI support QR for `8651600737@ptaxis`. Payment is handled by the user's UPI application. KeyPulse does not verify or store payment credentials.

## Included
- Variable extraction with values removed from output
- Two-file comparison by variable, value, or both
- Exact missing/extra/different/matching counts
- Search/filter of comparison results
- Local metadata history
- Full-project ZIP download button
- Animated UPI support area
- Contact links
- Terms of Use, License and Security notes
- No server required
